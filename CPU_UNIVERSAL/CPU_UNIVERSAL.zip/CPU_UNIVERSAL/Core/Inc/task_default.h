/*
  Configura��o do sistema interno de clock do uC.
*/


#ifndef _TASK_DEFAULT_HEADER_SENTRY_
#define _TASK_DEFAULT_HEADER_SENTRY_

#include "main.h"
	
	//
	// Prototipo das fun��es exportadas.
	//
	void StartDefaultTask(void const * argument);

#endif


