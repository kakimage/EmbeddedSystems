/*
  Thread que trata comunica��o com Bluetooth.
*/


#ifndef _TASK_BLE_HEADER_SENTRY_
#define _TASK_BLE_HEADER_SENTRY_

#include "main.h"
	
	//
	// Prototipo das fun��es exportadas.
	//
	void ble(void const * argument);

#endif

