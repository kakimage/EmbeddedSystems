/*
  Thread que trata pinos de GPIO.
*/


#ifndef _TASK_GPIO_HEADER_SENTRY_
#define _TASK_GPIO_HEADER_SENTRY_

#include "main.h"
	
	//
	// Prototipo das fun��es exportadas.
	//
	void gpio(void const * argument);

#endif

