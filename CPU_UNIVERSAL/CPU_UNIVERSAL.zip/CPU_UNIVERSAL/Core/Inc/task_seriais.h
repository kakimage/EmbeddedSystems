/*
  Thread que trata das seriais I2C e SPI.
*/


#ifndef _TASK_SERIAIS_HEADER_SENTRY_
#define _TASK_SERIAIS_HEADER_SENTRY_

#include "main.h"
	
	//
	// Prototipo das fun��es exportadas.
	//
	void seriais(void const * argument);

#endif

